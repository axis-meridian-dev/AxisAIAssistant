"""
Knowledge Base Tool — Local RAG (Retrieval Augmented Generation).

Ingests your files into a local vector database (ChromaDB) so the LLM can
search and reference your documents, code, notes, and research when answering.

Supports: .txt, .md, .py, .js, .ts, .json, .yaml, .yml, .toml, .cfg, .ini,
          .html, .css, .sh, .bash, .rs, .go, .java, .c, .cpp, .h, .hpp,
          .pdf, .csv, .log, .xml, .sql, .env, .conf, .rst, .tex

Flow:
  1. Ingest: scan directories → chunk files → embed with local model → store in ChromaDB
  2. Query: embed question → find similar chunks → inject into LLM context
  3. The LLM sees your actual file content alongside the question

Everything runs locally. No data leaves your machine.
"""

import os
import hashlib
import json
import time
from pathlib import Path
from typing import Callable
from datetime import datetime

from tools.base import BaseTool

# ── File type handlers ──────────────────────────────────────────────────────

TEXT_EXTENSIONS = {
    ".txt", ".md", ".py", ".js", ".ts", ".jsx", ".tsx", ".json", ".yaml",
    ".yml", ".toml", ".cfg", ".ini", ".html", ".css", ".sh", ".bash",
    ".rs", ".go", ".java", ".c", ".cpp", ".h", ".hpp", ".sql", ".env",
    ".conf", ".rst", ".tex", ".log", ".xml", ".csv", ".r", ".rb",
    ".php", ".swift", ".kt", ".scala", ".lua", ".vim", ".dockerfile",
    ".makefile", ".cmake", ".gradle", ".properties", ".gitignore",
    ".editorconfig", ".prettierrc", ".eslintrc",
}

PDF_SUPPORT = False
try:
    import fitz  # PyMuPDF
    PDF_SUPPORT = True
except ImportError:
    pass


def read_text_file(path: Path, max_chars: int = 100_000) -> str | None:
    """Read a text file, return None if binary/unreadable."""
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(max_chars)
    except Exception:
        return None


def read_pdf_file(path: Path) -> str | None:
    """Extract text from PDF using PyMuPDF."""
    if not PDF_SUPPORT:
        return None
    try:
        doc = fitz.open(str(path))
        text = ""
        for page in doc:
            text += page.get_text() + "\n"
        doc.close()
        return text.strip() if text.strip() else None
    except Exception:
        return None


def read_file_content(path: Path) -> str | None:
    """Read file content based on extension."""
    ext = path.suffix.lower()
    if ext == ".pdf":
        return read_pdf_file(path)
    elif ext in TEXT_EXTENSIONS or ext == "":
        return read_text_file(path)
    return None


# ── Chunking ────────────────────────────────────────────────────────────────

def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200) -> list[str]:
    """
    Split text into overlapping chunks.
    Uses paragraph boundaries when possible, falls back to character splitting.
    """
    if len(text) <= chunk_size:
        return [text]
    
    # Try paragraph-based splitting first
    paragraphs = text.split("\n\n")
    chunks = []
    current_chunk = ""
    
    for para in paragraphs:
        if len(current_chunk) + len(para) + 2 <= chunk_size:
            current_chunk += para + "\n\n"
        else:
            if current_chunk.strip():
                chunks.append(current_chunk.strip())
            # If single paragraph is too long, split by lines
            if len(para) > chunk_size:
                lines = para.split("\n")
                current_chunk = ""
                for line in lines:
                    if len(current_chunk) + len(line) + 1 <= chunk_size:
                        current_chunk += line + "\n"
                    else:
                        if current_chunk.strip():
                            chunks.append(current_chunk.strip())
                        current_chunk = line + "\n"
            else:
                current_chunk = para + "\n\n"
    
    if current_chunk.strip():
        chunks.append(current_chunk.strip())
    
    # Add overlap between chunks
    if overlap > 0 and len(chunks) > 1:
        overlapped = [chunks[0]]
        for i in range(1, len(chunks)):
            # Prepend end of previous chunk
            prev_end = chunks[i - 1][-overlap:]
            overlapped.append(prev_end + "\n" + chunks[i])
        chunks = overlapped
    
    return chunks


def file_hash(path: Path) -> str:
    """Quick hash of file for change detection."""
    stat = path.stat()
    key = f"{path}:{stat.st_size}:{stat.st_mtime}"
    return hashlib.md5(key.encode()).hexdigest()


# ── Knowledge Base Tool ─────────────────────────────────────────────────────

class KnowledgeBaseTool(BaseTool):
    
    def __init__(self, config: dict):
        super().__init__(config)
        self.kb_config = config.get("knowledge_base", {})
        self.db_path = Path(self.kb_config.get(
            "db_path",
            str(Path.home() / ".local" / "share" / "ai-assistant" / "knowledge_db")
        ))
        self.db_path.mkdir(parents=True, exist_ok=True)
        
        self.chunk_size = self.kb_config.get("chunk_size", 1000)
        self.chunk_overlap = self.kb_config.get("chunk_overlap", 200)
        self.embed_model = self.kb_config.get("embed_model", "nomic-embed-text")
        self.max_results = self.kb_config.get("max_results", 5)
        
        # Track ingested files
        self.manifest_path = self.db_path / "manifest.json"
        self.manifest = self._load_manifest()
        
        # ChromaDB — lazy init
        self._chroma_client = None
        self._collection = None
    
    @property
    def collection(self):
        """Lazy-load ChromaDB collection."""
        if self._collection is None:
            import chromadb
            from chromadb.config import Settings
            
            self._chroma_client = chromadb.PersistentClient(
                path=str(self.db_path / "chroma"),
                settings=Settings(anonymized_telemetry=False)
            )
            self._collection = self._chroma_client.get_or_create_collection(
                name="knowledge_base",
                metadata={"hnsw:space": "cosine"}
            )
        return self._collection
    
    def _load_manifest(self) -> dict:
        if self.manifest_path.exists():
            with open(self.manifest_path) as f:
                return json.load(f)
        return {"files": {}, "stats": {"total_chunks": 0, "total_files": 0}}
    
    def _save_manifest(self):
        with open(self.manifest_path, "w") as f:
            json.dump(self.manifest, f, indent=2)
    
    def _embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings using Ollama's embedding model."""
        import ollama
        
        embeddings = []
        # Batch to avoid OOM
        batch_size = 32
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            response = ollama.embed(model=self.embed_model, input=batch)
            embeddings.extend(response["embeddings"])
        return embeddings
    
    # ── Public methods (exposed as tools) ───────────────────────────────────
    
    def ingest_directory(self, path: str = "~", recursive: bool = True,
                         file_types: str = "all") -> str:
        """
        Scan a directory and ingest all supported files into the knowledge base.
        This makes them searchable by the AI.
        """
        target = Path(path).expanduser().resolve()
        
        if not target.exists():
            return f"Directory not found: {target}"
        if not target.is_dir():
            return f"Not a directory: {target}"
        
        # Determine which extensions to include
        if file_types == "all":
            valid_ext = TEXT_EXTENSIONS | {".pdf"}
        elif file_types == "code":
            valid_ext = {".py", ".js", ".ts", ".jsx", ".tsx", ".rs", ".go",
                        ".java", ".c", ".cpp", ".h", ".hpp", ".rb", ".php",
                        ".sh", ".bash", ".sql", ".lua"}
        elif file_types == "docs":
            valid_ext = {".txt", ".md", ".rst", ".tex", ".pdf", ".html", ".xml"}
        else:
            valid_ext = set(f".{e.strip('.')}" for e in file_types.split(","))
        
        excluded_dirs = {".git", "node_modules", "__pycache__", ".cache",
                        ".venv", "venv", ".tox", "dist", "build", ".eggs",
                        ".mypy_cache", ".pytest_cache", "target"}
        
        # Collect files
        if recursive:
            files = [f for f in target.rglob("*") if f.is_file()]
        else:
            files = [f for f in target.iterdir() if f.is_file()]
        
        # Filter
        files = [
            f for f in files
            if f.suffix.lower() in valid_ext
            and not any(ex in f.parts for ex in excluded_dirs)
            and f.stat().st_size < 50 * 1024 * 1024  # 50MB max
        ]
        
        if not files:
            return f"No supported files found in {target}"
        
        ingested = 0
        skipped = 0
        errors = 0
        total_chunks = 0
        
        for filepath in files:
            try:
                fhash = file_hash(filepath)
                str_path = str(filepath)
                
                # Skip if already ingested and unchanged
                if str_path in self.manifest["files"]:
                    if self.manifest["files"][str_path]["hash"] == fhash:
                        skipped += 1
                        continue
                    else:
                        # File changed — remove old chunks and re-ingest
                        self._remove_file_chunks(str_path)
                
                # Read file
                content = read_file_content(filepath)
                if not content or len(content.strip()) < 10:
                    skipped += 1
                    continue
                
                # Chunk
                chunks = chunk_text(content, self.chunk_size, self.chunk_overlap)
                
                # Create metadata for each chunk
                ids = []
                documents = []
                metadatas = []
                
                for i, chunk in enumerate(chunks):
                    chunk_id = hashlib.md5(
                        f"{str_path}:chunk:{i}:{fhash}".encode()
                    ).hexdigest()
                    
                    ids.append(chunk_id)
                    documents.append(chunk)
                    metadatas.append({
                        "source": str_path,
                        "filename": filepath.name,
                        "extension": filepath.suffix,
                        "chunk_index": i,
                        "total_chunks": len(chunks),
                        "file_hash": fhash,
                        "ingested_at": datetime.now().isoformat(),
                        "file_size": filepath.stat().st_size,
                        "directory": str(filepath.parent),
                    })
                
                # Embed and store
                embeddings = self._embed(documents)
                
                self.collection.add(
                    ids=ids,
                    documents=documents,
                    embeddings=embeddings,
                    metadatas=metadatas,
                )
                
                # Update manifest
                self.manifest["files"][str_path] = {
                    "hash": fhash,
                    "chunks": len(chunks),
                    "ingested_at": datetime.now().isoformat(),
                    "size": filepath.stat().st_size,
                }
                
                ingested += 1
                total_chunks += len(chunks)
                
            except Exception as e:
                errors += 1
        
        # Update stats
        self.manifest["stats"]["total_files"] = len(self.manifest["files"])
        self.manifest["stats"]["total_chunks"] = self.collection.count()
        self._save_manifest()
        
        return (
            f"Ingestion complete:\n"
            f"  📥 Ingested: {ingested} files ({total_chunks} chunks)\n"
            f"  ⏭️  Skipped (unchanged): {skipped}\n"
            f"  ❌ Errors: {errors}\n"
            f"  📊 Total in knowledge base: {self.manifest['stats']['total_files']} files, "
            f"{self.manifest['stats']['total_chunks']} chunks\n"
            f"  📁 Database: {self.db_path}"
        )
    
    def ingest_file(self, path: str) -> str:
        """Ingest a single file into the knowledge base."""
        filepath = Path(path).expanduser().resolve()
        
        if not filepath.exists():
            return f"File not found: {filepath}"
        if not filepath.is_file():
            return f"Not a file: {filepath}"
        
        content = read_file_content(filepath)
        if not content:
            return f"Could not read file (unsupported format or binary): {filepath}"
        
        fhash = file_hash(filepath)
        str_path = str(filepath)
        
        # Remove old version if exists
        if str_path in self.manifest["files"]:
            self._remove_file_chunks(str_path)
        
        chunks = chunk_text(content, self.chunk_size, self.chunk_overlap)
        
        ids = []
        documents = []
        metadatas = []
        
        for i, chunk in enumerate(chunks):
            chunk_id = hashlib.md5(
                f"{str_path}:chunk:{i}:{fhash}".encode()
            ).hexdigest()
            
            ids.append(chunk_id)
            documents.append(chunk)
            metadatas.append({
                "source": str_path,
                "filename": filepath.name,
                "extension": filepath.suffix,
                "chunk_index": i,
                "total_chunks": len(chunks),
                "file_hash": fhash,
                "ingested_at": datetime.now().isoformat(),
            })
        
        embeddings = self._embed(documents)
        
        self.collection.add(
            ids=ids,
            documents=documents,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        
        self.manifest["files"][str_path] = {
            "hash": fhash,
            "chunks": len(chunks),
            "ingested_at": datetime.now().isoformat(),
            "size": filepath.stat().st_size,
        }
        self.manifest["stats"]["total_files"] = len(self.manifest["files"])
        self.manifest["stats"]["total_chunks"] = self.collection.count()
        self._save_manifest()
        
        return (
            f"Ingested: {filepath.name}\n"
            f"  Chunks: {len(chunks)}\n"
            f"  Size: {filepath.stat().st_size} bytes"
        )
    
    def query_knowledge(self, query: str, max_results: int = 5,
                        filter_extension: str = None,
                        filter_directory: str = None) -> str:
        """
        Search the knowledge base for content relevant to a query.
        Returns the most relevant chunks from your ingested files.
        """
        if self.collection.count() == 0:
            return "Knowledge base is empty. Use ingest_directory or ingest_file first."
        
        # Build filter
        where = {}
        if filter_extension:
            where["extension"] = filter_extension
        if filter_directory:
            where["directory"] = filter_directory
        
        # Embed the query
        query_embedding = self._embed([query])[0]
        
        # Search
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(max_results, self.collection.count()),
            where=where if where else None,
            include=["documents", "metadatas", "distances"]
        )
        
        if not results["documents"][0]:
            return f"No relevant results found for: '{query}'"
        
        # Format results
        lines = [f"Knowledge base results for: '{query}'\n"]
        
        for i, (doc, meta, dist) in enumerate(zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        )):
            similarity = 1 - dist  # cosine distance to similarity
            source = meta.get("filename", "unknown")
            chunk_idx = meta.get("chunk_index", "?")
            total = meta.get("total_chunks", "?")
            
            lines.append(
                f"── Result {i+1} (similarity: {similarity:.2%}) ──\n"
                f"Source: {meta.get('source', 'unknown')} "
                f"(chunk {chunk_idx}/{total})\n"
                f"{doc}\n"
            )
        
        return "\n".join(lines)
    
    def knowledge_stats(self) -> str:
        """Get statistics about the knowledge base."""
        stats = self.manifest["stats"]
        files = self.manifest["files"]
        
        if not files:
            return "Knowledge base is empty. Use ingest_directory to add files."
        
        # Count by extension
        ext_counts = {}
        total_size = 0
        for path, info in files.items():
            ext = Path(path).suffix.lower() or "(no ext)"
            ext_counts[ext] = ext_counts.get(ext, 0) + 1
            total_size += info.get("size", 0)
        
        # Count by directory (top-level grouping)
        dir_counts = {}
        home = str(Path.home())
        for path in files:
            rel = path.replace(home, "~")
            parts = Path(rel).parts
            top_dir = "/".join(parts[:3]) if len(parts) > 2 else "/".join(parts[:2])
            dir_counts[top_dir] = dir_counts.get(top_dir, 0) + 1
        
        lines = [
            "Knowledge Base Statistics:\n",
            f"  Total files:  {stats['total_files']}",
            f"  Total chunks: {stats['total_chunks']}",
            f"  Total size:   {total_size / 1024 / 1024:.1f} MB",
            f"  Database:     {self.db_path}\n",
            "  By file type:"
        ]
        for ext, count in sorted(ext_counts.items(), key=lambda x: -x[1]):
            lines.append(f"    {ext}: {count}")
        
        lines.append("\n  Top directories:")
        for d, count in sorted(dir_counts.items(), key=lambda x: -x[1])[:10]:
            lines.append(f"    {d}: {count} files")
        
        return "\n".join(lines)
    
    def remove_source(self, path: str) -> str:
        """Remove a file or directory from the knowledge base."""
        target = Path(path).expanduser().resolve()
        str_target = str(target)
        
        removed = 0
        to_remove = []
        
        for fpath in list(self.manifest["files"].keys()):
            if fpath.startswith(str_target):
                to_remove.append(fpath)
        
        for fpath in to_remove:
            self._remove_file_chunks(fpath)
            del self.manifest["files"][fpath]
            removed += 1
        
        self.manifest["stats"]["total_files"] = len(self.manifest["files"])
        self.manifest["stats"]["total_chunks"] = self.collection.count()
        self._save_manifest()
        
        if removed == 0:
            return f"No entries found for: {target}"
        return f"Removed {removed} files from knowledge base."
    
    def list_sources(self, path_filter: str = None) -> str:
        """List all files currently in the knowledge base."""
        files = self.manifest["files"]
        
        if not files:
            return "Knowledge base is empty."
        
        if path_filter:
            files = {
                k: v for k, v in files.items()
                if path_filter.lower() in k.lower()
            }
        
        if not files:
            return f"No files matching '{path_filter}' in knowledge base."
        
        home = str(Path.home())
        lines = [f"Knowledge base sources ({len(files)} files):\n"]
        
        for fpath, info in sorted(files.items()):
            display = fpath.replace(home, "~")
            chunks = info.get("chunks", "?")
            ingested = info.get("ingested_at", "?")[:10]
            lines.append(f"  📄 {display}  ({chunks} chunks, ingested {ingested})")
        
        if len(lines) > 52:
            lines = lines[:50]
            lines.append(f"\n  ... and {len(files) - 49} more files")
        
        return "\n".join(lines)
    
    def _remove_file_chunks(self, filepath: str):
        """Remove all chunks for a specific file from ChromaDB."""
        try:
            # Find chunk IDs for this file
            results = self.collection.get(
                where={"source": filepath},
                include=[]
            )
            if results["ids"]:
                self.collection.delete(ids=results["ids"])
        except Exception:
            pass
    
    # ── Tool definitions ────────────────────────────────────────────────────
    
    def get_tool_definitions(self) -> list[dict]:
        return [
            {
                "type": "function",
                "function": {
                    "name": "ingest_directory",
                    "description": "Scan a directory and add all supported files to the knowledge base. This makes them searchable by the AI. Supports text files, code, markdown, PDFs, configs, etc. Skips already-ingested unchanged files.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string", "description": "Directory path to ingest (default: ~)"},
                            "recursive": {"type": "boolean", "description": "Scan subdirectories (default: true)"},
                            "file_types": {"type": "string", "description": "'all', 'code', 'docs', or comma-separated extensions like '.py,.md,.txt'"}
                        }
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "ingest_file",
                    "description": "Add a single file to the knowledge base.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string", "description": "File path to ingest"}
                        },
                        "required": ["path"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "query_knowledge",
                    "description": "Search the knowledge base for information relevant to a question. Returns the most relevant chunks from ingested files. USE THIS to answer questions about the user's projects, code, notes, or research.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Natural language query or keywords"},
                            "max_results": {"type": "integer", "description": "Number of results (default: 5)"},
                            "filter_extension": {"type": "string", "description": "Filter by file extension (e.g., '.py')"},
                            "filter_directory": {"type": "string", "description": "Filter by directory path"}
                        },
                        "required": ["query"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "knowledge_stats",
                    "description": "Get statistics about the knowledge base — file counts, types, sizes, and directories.",
                    "parameters": {"type": "object", "properties": {}}
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "remove_source",
                    "description": "Remove a file or all files under a directory from the knowledge base.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "path": {"type": "string", "description": "File or directory path to remove"}
                        },
                        "required": ["path"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "list_sources",
                    "description": "List all files currently in the knowledge base, optionally filtered by path.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "path_filter": {"type": "string", "description": "Filter results by path substring"}
                        }
                    }
                }
            }
        ]
    
    def get_handlers(self) -> dict[str, Callable]:
        return {
            "ingest_directory": self.ingest_directory,
            "ingest_file": self.ingest_file,
            "query_knowledge": self.query_knowledge,
            "knowledge_stats": self.knowledge_stats,
            "remove_source": self.remove_source,
            "list_sources": self.list_sources,
        }
