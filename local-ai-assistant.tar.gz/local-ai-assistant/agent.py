"""
Core Agent — LLM reasoning + tool dispatch loop.

Uses Ollama's tool-calling API to let the LLM decide which tools to invoke.
Runs a loop: LLM → tool call → result → LLM → ... until final answer.
"""

import json
import ollama
from rich.console import Console
from rich.table import Table

from tools.file_manager import FileManagerTool
from tools.web_search import WebSearchTool
from tools.desktop_control import DesktopControlTool
from tools.system_info import SystemInfoTool
from tools.knowledge_base import KnowledgeBaseTool
from tools.legal_research import LegalResearchTool
from tools.document_writer import DocumentWriterTool

console = Console()

SYSTEM_PROMPT = """You are a powerful local AI assistant running directly on the user's Linux computer.
You have full access to the local filesystem, web search, desktop control, and a local knowledge base.

IMPORTANT RULES:
- You are running LOCALLY — all data stays on this machine. Be direct and helpful.
- When the user asks to do something (open files, search, manage apps), USE YOUR TOOLS. Don't just describe what you would do.
- For file operations, always use absolute paths. Expand ~ to the actual home directory.
- For destructive operations (delete, move, overwrite), confirm with the user first by stating what you plan to do.
- When searching the web, synthesize results into a clear answer — don't just dump raw results.
- For desktop control, describe what you're doing as you do it.
- Be concise. No filler. The user is technical.

KNOWLEDGE BASE:
- You have a local vector database of the user's files. Use query_knowledge to search it.
- When the user asks about their projects, code, notes, or research, ALWAYS query the knowledge base first.
- The user can ingest directories or files to grow the knowledge base.
- The knowledge base persists between sessions — ingested files stay indexed.

You have these tool categories:
1. FILE MANAGEMENT — read, write, search, organize, list files and directories
2. WEB SEARCH — search the internet and fetch web pages
3. DESKTOP CONTROL — launch apps, manage windows, clipboard, screenshots, run commands
4. SYSTEM INFO — hardware stats, running processes, disk usage, network info
5. KNOWLEDGE BASE — ingest files into vector DB, semantic search across all your documents
6. LEGAL RESEARCH — look up statutes, search case law, find statistics, clip news articles, generate research briefs
7. DOCUMENT WRITER — create essays, articles, debate prep docs, briefs, and reports from your research

LEGAL RESEARCH WORKFLOW:
- When the user asks about a law or legal question, FIRST look up the actual statute, then explain it.
- Use search_case_law to find relevant court decisions that interpret the statute.
- For case prep, generate_research_brief creates a structured template, then fill it by looking up statutes, cases, and stats.
- Downloaded statutes and opinions go to ~/LegalResearch/ — remind the user to ingest them into the knowledge base.
- Use write_document or write_debate_prep to produce finished essays, articles, and trial preparation materials.
- When writing legal documents, cite specific statutes and cases. Use query_knowledge to pull from already-ingested research.
- For news monitoring, use search_legal_news and clip_article to build a library of current events.
- When discussing legal matters, always note that you are an AI research tool, not a lawyer.

Think step by step about which tools to use, then use them."""


class Agent:
    def __init__(self, config: dict):
        self.config = config
        self.history: list[dict] = []
        self.ollama_host = config["llm"]["ollama_host"]
        
        # Initialize tools
        self.tool_instances = {
            "file_manager": FileManagerTool(config),
            "web_search": WebSearchTool(config),
            "desktop_control": DesktopControlTool(config),
            "system_info": SystemInfoTool(config),
            "knowledge_base": KnowledgeBaseTool(config),
            "legal_research": LegalResearchTool(config),
            "document_writer": DocumentWriterTool(config),
        }
        
        # Build tool definitions for Ollama
        self.tools = []
        for instance in self.tool_instances.values():
            self.tools.extend(instance.get_tool_definitions())
        
        # Map tool names to handler functions
        self.tool_handlers = {}
        for instance in self.tool_instances.values():
            self.tool_handlers.update(instance.get_handlers())
    
    def list_tools(self) -> list[str]:
        return list(self.tool_instances.keys())
    
    def print_tools(self):
        table = Table(title="Available Tools", border_style="cyan")
        table.add_column("Category", style="bold")
        table.add_column("Functions", style="dim")
        
        for name, instance in self.tool_instances.items():
            funcs = ", ".join(d["function"]["name"] for d in instance.get_tool_definitions())
            table.add_row(name, funcs)
        
        console.print(table)
    
    def clear_history(self):
        self.history = []
    
    async def process(self, user_input: str) -> str:
        """Process user input through the agent loop."""
        
        self.history.append({"role": "user", "content": user_input})
        
        # Determine which model to use
        # Use fast model for simple queries, primary for complex ones
        model = self._select_model(user_input)
        
        messages = [{"role": "system", "content": SYSTEM_PROMPT}] + self.history
        
        # Agent loop — keep going until LLM produces a final text response
        max_iterations = 10
        for i in range(max_iterations):
            try:
                response = ollama.chat(
                    model=model,
                    messages=messages,
                    tools=self.tools,
                    options={
                        "temperature": self.config["llm"]["temperature"],
                        "num_ctx": self.config["llm"]["context_window"],
                    }
                )
            except Exception as e:
                error_msg = f"LLM error: {e}"
                console.print(f"[red]{error_msg}[/red]")
                return error_msg
            
            msg = response["message"]
            messages.append(msg)
            
            # Check if there are tool calls
            if msg.get("tool_calls"):
                for tool_call in msg["tool_calls"]:
                    func_name = tool_call["function"]["name"]
                    func_args = tool_call["function"]["arguments"]
                    
                    console.print(f"  [dim]→ Calling: {func_name}({json.dumps(func_args, default=str)[:100]}...)[/dim]")
                    
                    # Execute the tool
                    handler = self.tool_handlers.get(func_name)
                    if handler:
                        try:
                            result = handler(**func_args)
                        except Exception as e:
                            result = f"Tool error: {e}"
                    else:
                        result = f"Unknown tool: {func_name}"
                    
                    # Add tool result to messages
                    messages.append({
                        "role": "tool",
                        "content": str(result)
                    })
            else:
                # No tool calls — this is the final response
                final = msg.get("content", "")
                self.history.append({"role": "assistant", "content": final})
                
                # Trim history to prevent context overflow
                if len(self.history) > 40:
                    self.history = self.history[-30:]
                
                return final
        
        return "Reached maximum tool iterations. Please try a simpler request."
    
    def _select_model(self, user_input: str) -> str:
        """Use fast model for simple tasks, primary for complex ones."""
        simple_patterns = [
            "what time", "hello", "hi", "hey", "thanks", "thank you",
            "what's up", "how are you", "clear", "help"
        ]
        lower = user_input.lower().strip()
        if any(lower.startswith(p) or lower == p for p in simple_patterns):
            return self.config["llm"]["fast_model"]
        return self.config["llm"]["primary_model"]
